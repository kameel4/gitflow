import pygame, random

if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption('balls')
    size = width, height = 400, 800
    screen = pygame.display.set_mode(size)


class Sqr(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.image = pygame.Surface((30, 30))
        pygame.draw.rect(self.image, (0, 0, 255),
                         (x, y, x + 30, y + 30))
        self.rect = pygame.Rect(x, y, x + 30, y + 30)
        self.vx = 0
        self.vy = 1

    def update(self):
        self.rect.x += self.vx
        if self.rect.y < 770 and pygame.sprite.spritecollideany(self, platforms) == None:
            self.rect.y += self.vy
        elif self.rect.y == 770:
            self.rect.y = 0

balls = pygame.sprite.Group()
square = Sqr(0, 0)
balls.add(square)
platforms = pygame.sprite.Group()

clock = pygame.time.Clock()
running = True
while running:
    screen.fill((255, 255, 255))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONDOWN:
            plat = pygame.sprite.Sprite()
            plat.image = pygame.image.load("data/platform.png")
            plat.rect = plat.image.get_rect()
            plat.rect.x = event.pos[0]
            plat.rect.y = event.pos[1]
            platforms.add(plat)
    keys = pygame.key.get_pressed()
    if keys[pygame.K_RIGHT] and square.rect.x < 370:
        square.rect.x += 2
    if keys[pygame.K_LEFT] and square.rect.x > 5:
        square.rect.x -= 2
    balls.update()
    balls.draw(screen)
    platforms.draw(screen)
    pygame.display.flip()
    clock.tick(120)
